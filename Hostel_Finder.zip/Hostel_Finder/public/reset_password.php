<?php
require 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['token'])) {
    $token = $_GET['token'];
} else {
    die("Invalid request.");
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $token = $_POST['token'];
    $new_password = $_POST['new_password'];
    $confirm_password = $_POST['confirm_password'];

    // Basic password validation
    if (strlen($new_password) < 8) {
        die("Password must be at least 8 cSharacters long.");
    }

    if ($new_password !== $confirm_password) {
        die("Passwords do not match.");
    }

    // Prepare the statement to select the user with the given token and check the expiry
    $stmt = $conn->prepare("SELECT id FROM users WHERE reset_token = ? AND reset_expiry > NOW()");
    if ($stmt === false) {
        die("Error: " . $conn->error);
    }

    $stmt->bind_param("s", $token);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id);
        $stmt->fetch();

        $new_password_hashed = password_hash($new_password, PASSWORD_DEFAULT);
        $update_stmt = $conn->prepare("UPDATE users SET password = ?, reset_token = NULL, reset_expiry = NULL WHERE id = ?");
        if ($update_stmt === false) {
            die("Error: " . $conn->error);
        }

        $update_stmt->bind_param("si", $new_password_hashed, $id);

        if ($update_stmt->execute()) {
            echo "Password has been reset successfully.";
        } else {
            echo "Error updating password: " . $conn->error;
        }

        $update_stmt->close();
    } else {
        echo "Invalid or expired token.";
    }

    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="reset_password.css"> 
</head>
<body>
    <div class="container-fluid">
        <div class="form-container">
            <h2>Reset Password</h2>
            <div class="form-content">
                <form action="reset_password.php" method="post">
                    <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">
                    <input type="password" name="new_password" placeholder="Enter New Password" required>
                    <input type="password" name="confirm_password" placeholder="Confirm New Password" required>
                    <button type="submit">Reset Password</button>
                </form>
            </div>
        </div>
    </div>
</body>
</html>
