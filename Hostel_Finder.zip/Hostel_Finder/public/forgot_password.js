document.getElementById('forgotPasswordForm').addEventListener('submit', function(event) {
    event.preventDefault();

    const email = event.target.email.value;
    
    if (email) {
        // Add your AJAX request here to send the email to the server
        console.log('Email submitted:', email);
        
        // Example of an AJAX request
        fetch('forgot_password.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: new URLSearchParams({ email: email })
        })
        .then(response => response.text())
        .then(data => {
            // Handle server response here
            console.log(data);
        })
        .catch(error => {
            console.error('Error:', error);
        });
    } else {
        alert('Please enter your email address.');
    }
});
