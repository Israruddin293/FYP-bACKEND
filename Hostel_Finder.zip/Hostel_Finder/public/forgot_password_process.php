<?php
session_start();
require 'config.php';
require 'Mail/phpmailer/class.phpmailer.php';
require 'Mail/phpmailer/class.smtp.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if email is set in the POST data
    if (!isset($_POST["email"])) {
        die("Email field is missing.");
    }

    // Sanitize and validate email
    $email = filter_var($_POST["email"], FILTER_SANITIZE_EMAIL);
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        die("Invalid email address.");
    }

    $email = $conn->real_escape_string($email);

    $stmt = $conn->prepare("SELECT id, is_verified FROM users WHERE email = ?");
    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id, $is_verified);
        $stmt->fetch();

        if ($is_verified == 1) {
            $reset_token = bin2hex(random_bytes(50));
            $reset_expiry = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $update_stmt = $conn->prepare("UPDATE users SET reset_token = ?, reset_expiry = ? WHERE id = ?");
            if (!$update_stmt) {
                die("Prepare failed: " . $conn->error);
            }

            $update_stmt->bind_param("ssi", $reset_token, $reset_expiry, $id);

            if ($update_stmt->execute()) {
                $reset_link = "http://localhost/Hostel_Finder/public/reset_password.php?token=" . $reset_token;

                $mail = new PHPMailer(true);
                try {
                    $mail->isSMTP();
                    $mail->Host = 'smtp.gmail.com';
                    $mail->SMTPAuth = true;
                    $mail->Username = 'uisrar293@gmail.com'; 
                    $mail->Password = 'abzx nxip svsl fvuw'; 
                    $mail->SMTPSecure = 'tls';
                    $mail->Port = 587;

                    $mail->setFrom('uisrar293@gmail.com', 'Hostel Finder'); // Replace with your email
                    $mail->addAddress($email);
                    $mail->Subject = 'Password Reset Request';
                    $mail->Body = 'Click on the following link to reset your password: ' . $reset_link;

                    $mail->send();
                    echo "Password reset link has been sent to your email.";
                } catch (Exception $e) {
                    echo "Failed to send email. Error: " . $mail->ErrorInfo;
                }
            } else {
                echo "Error: " . $conn->error;
            }
            $update_stmt->close();
        } else {
            echo "Email is not verified.";
        }
    } else {
        echo "No user found with this email.";
    }

    $stmt->close();
    $conn->close();
} else {
    die("Invalid request.");
}
?>
